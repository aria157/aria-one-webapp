export default function Launch137() {
  return (
    <div className="min-h-screen bg-black text-white p-16">
      <h1 className="text-7xl font-bold text-center" style={{textShadow:"0 0 30px #fff78e"}}>
        ARIA VISION
      </h1>
      <h2 className="text-4xl text-center mt-4 mb-10">
        Launching <span className="text-[#fff78e]">10 • 12 • 25</span>
      </h2>
      <p className="text-center text-gray-300 text-xl max-w-3xl mx-auto">
        The world's first screenshot-intelligent, encrypted identity vault.
      </p>
    </div>
  );
}