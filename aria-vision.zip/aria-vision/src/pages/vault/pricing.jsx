export default function Pricing() {
  return (
    <div className="text-white p-12">
      <h1 className="text-5xl mb-12" style={{textShadow:"0 0 25px #fff78e"}}>Pricing</h1>
    </div>
  );
}