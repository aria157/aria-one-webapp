import { ethers } from "ethers";
import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  res.json({ success: true });
}